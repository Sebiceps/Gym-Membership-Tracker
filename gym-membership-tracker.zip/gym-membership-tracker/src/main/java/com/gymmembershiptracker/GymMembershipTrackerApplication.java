package com.gymmembershiptracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymMembershipTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymMembershipTrackerApplication.class, args);
	}

}
